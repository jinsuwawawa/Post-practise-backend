package com.example.demo128;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Demo128ApplicationTests {

    @Test
    void contextLoads() {
    }

}
